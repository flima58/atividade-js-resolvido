

$(".checkbox-wrap").click(function () {
  
  var nameQuestion = $(this).children('input[type=radio]').attr("name");
  $('input[name=' + nameQuestion+ ']').each(function () {
        $(this).parent().removeClass("selecionada");//remove o check quand você selecina outro check 
        $(".acoes .bt").css({ "display": "none" })
        
         
  });
       $(this).addClass("selecionada");//Adiciona classe quando selecionar o radio
       $(".acoes .bt").css({ "display": "block" })//Deixando visivel o botão
       
});

$( ".checkbox-wrap" ).click(function() {
  $( "input[type=radio]:checked" ).toggle('slow');
});


$(".bt-confirmar").click(function () {
  $(".selecionada").each(function (i, elemento) {
    //Pegar o id do Radio Selecioando
    var resp = $(elemento).find("input[type=radio]:checked").attr("id");
    if (resp == 'a1' || resp == 'a2') {
          $(".feedback-positivo").css({ "display": "block" })

          //Imprimindo a resposta
          $(".acoes .bt").css({ "display": "none" })

          //Desabilitando os elementos
          $("input").attr('disabled','disabled')
      
    } else {
          $(".feedback-negativo").css({ "display": "block" })

          //Imprimindo a resposta
          $(".acoes .bt").css({ "display": "none" })

          //Desabilitando os elementos
          $("input").attr('disabled','disabled')
    }  

  })

})

$(document).ready(function () {
//Gabarito não possui nenhuma resposta.  
  $.get("http://localhost//atividade-js/data/exercicio.js", function (data) {
    //Json não possui resposta
    console.log(data.gabrito);
  });
});















