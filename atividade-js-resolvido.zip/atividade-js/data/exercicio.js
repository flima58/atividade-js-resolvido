[
	{
		"gabarito": [3]
	}
]